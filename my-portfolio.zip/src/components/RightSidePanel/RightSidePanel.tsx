import React from 'react'

function RightSidePanel() {
  return (
    <div>RightSidePanel</div>
  )
}

export default RightSidePanel